#!/bin/sh
node ./source/main.js $1 $2