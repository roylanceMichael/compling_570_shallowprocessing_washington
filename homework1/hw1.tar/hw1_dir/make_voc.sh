#!/bin/sh
node source/vocabulary_main.js