#!/bin/sh
node source/tokenizer_main.js